Note:

1 . ElecFreaks TFT LCD Module default use the 16bit mode

2. The I/O of the TFT01 is 3.3v voltage , so you had better not to directly connect it to the 5v voltage I/O .We suggest using the 30K and 20K resistor to reduce voltage.

3. We recommand using with Mega2560 and TFT Mega Shield. If you use the TFT-2.4 shield , the DB8-DB15 is uesd, please remember to pull the DB0-DB7 to GND.
